package com.example.demo.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// Rest(json을 return하겠다) + Controller 
@RestController
public class HelloController {
	
	@RequestMapping("/hello")
	public String hello() {
		return "Hello 스프링부트!!";
	}
}
