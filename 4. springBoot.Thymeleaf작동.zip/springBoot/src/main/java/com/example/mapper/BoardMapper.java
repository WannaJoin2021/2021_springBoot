package com.example.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.example.domain.BoardDomain;

@Mapper
public interface BoardMapper {

	/* 위에 select문을 사용하기 위해 param을 지정해준다. sql문에 title값을 주기 위해 */
	@Select("select * from board where id=#{id}")
	public BoardDomain getId(@Param("id") int id) throws Exception;
//	public int getId(int id) throws Exception;

	@Select("select * from board where title=#{title}")
	public String getTitle(@Param("title") String title) throws Exception;
//	public String getTitle(String title) throws Exception;

}
