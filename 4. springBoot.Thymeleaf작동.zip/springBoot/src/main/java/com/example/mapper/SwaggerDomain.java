package com.example.mapper;

import lombok.Data;

@Data		//롬북설치
public class SwaggerDomain {

	private String id;
	private String name;
	private String email;
	
	
}