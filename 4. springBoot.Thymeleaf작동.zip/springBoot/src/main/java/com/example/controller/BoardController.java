package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.domain.BoardDomain;
import com.example.mapper.BoardMapper;

@Controller
public class BoardController {

	@Autowired
	private BoardMapper boardMapper;

	// http://localhost:9090/thymeleaf 실행
	@RequestMapping(value = "/thymeleaf")
	public void thymeleaf(Model model, BoardDomain boardDTO) throws Exception {

//		String title = "test";
//		boardDTO.setTitle(title);
//		model.addAttribute("title", boardMapper.getTitle(title));

		int id = 1;
		boardDTO.setId(id);
		boardDTO = boardMapper.getId(id);
		
		model.addAttribute("id", boardMapper.getId(id));
		model.addAttribute("boardDTO", boardDTO);

		
	}

}
