package com.example.demo.domain;

import lombok.Data;
import lombok.ToString;

//	@ToString(exclude= {"upw", "naverid")	//노출시키지 않겠다

@Data		//롬북
@ToString
public class BoardDomain {

	public int id;
	public String title;
	public String contents;
	public String writer;
	public String reg_date;
	public String mod_date;
	public String use_yn;
	
//	private String upw;
//	private String naverid;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	public String getMod_date() {
		return mod_date;
	}
	public void setMod_date(String mod_date) {
		this.mod_date = mod_date;
	}
	public String getUse_yn() {
		return use_yn;
	}
	public void setUse_yn(String use_yn) {
		this.use_yn = use_yn;
	}


}
