package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.domain.BoardDomain;
import com.example.demo.mapper.BoardMapper;

@Controller
public class BoardController {

	@Autowired
	private BoardMapper mapper;

	//http://localhost:9090/thymeleaf  실행
	@RequestMapping("/thymeleaf")
	public void thymeleaf(Model model) throws Exception {
		String title = "test";
		model.addAttribute("title", mapper.getTitle(title));

		BoardDomain domain = mapper.getId(3);
		model.addAttribute("domain", domain);
	}

}
