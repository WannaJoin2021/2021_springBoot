package com.example.demo.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.example.demo.domain.BoardDomain;

public interface BoardMapper {

	@Select("select * from board where title=#{title}")
	public String getTitle(@Param("title") String title) throws Exception;
	
	public BoardDomain getId(@Param("id") int id) throws Exception;
	
	
}
