package com.example.demo;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// SpringBoot Application.properties 를 실행하는 메인클래스로 가장먼저 실행됨

@SpringBootApplication
@MapperScan(value={"com.example.demo.mapper"})	//mapper를 스캔해서 application(아래 클래스에) 올려준다

public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	

}
